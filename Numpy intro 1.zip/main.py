import numpy as np
'''
Program to check the basic functionality of numpy package
'''

#1D Array creation and attributes
a = np.array([1,2,3,4])
print("1D array: \n{}".format(a))
print("Dimensions: {2}\nSize: {0}\nShape: {1}\n".format(a.size,a.shape,a.ndim))
del a

#2D Array creation and attributes
a = np.array([[1,2,3],[4,5,6]])
print("2D array: \n{}".format(a))
print("Dimensions: {2}\nSize: {0}\nShape: {1}\n".format(a.size,a.shape,a.ndim))
del a

#3D Array creation and attributes
a = np.array([[[1,2,3],[4,5,6],[7,8,9]],[[10,11,12],[13,14,15],[16,17,18]],[[19,20,21],[22,23,24],[25,26,27]]])
print("3D array: \n{}".format(a))
print("Dimensions: {2}\nSize: {0}\nShape: {1}\n".format(a.size,a.shape,a.ndim))
del a

#Linear space
a = np.linspace(0,1,7)
print("Array created using linspace():\n{}\n".format(a))
del a

#Array of ones
a = np.ones((3,3,3,3))
print("Array of ones:\n{}\n".format(a))
del a

#Array of zeros
a = np.zeros((3,3,3))
print("Array of zeroes:\n{}\n".format(a))
del a

#Identity matrix
a = np.eye(3,10)
print("Identity matrix:\n{}\n".format(a))
del a

#Diagonal array
a = np.diag([1,2,3])
print("1D input diagonal array:\n{}\n".format(a))
print("Extracted diagonal:\n{}\n".format(np.diag(a)))
del a

a = np.diag([[1,2,3],[4,5,6],[7,8,9]])
print("2D input diagonal matrix:\n{}\n".format(a))
print("Extracted diagonal:\n{}\n".format(np.diag(a)))
del a

