import matplotlib.pyplot as plt
import numpy as np

def square(x):
  return x ** 2

def operation2(x):
  return x + (x ** 3)

l1 = np.random.randn(10)
l2 = list(map(square,l1))
l3 = list(map(operation2,l1))

print ("List1: {l1}\nList2: {l2}\n".format(l1 = l1, l2 = l2))

#plt.setp(p1[0],color )
#plt.show()
plt.figure(1)
plt.subplot(211)
plt.plot(l1,l2)
#plt.figure(2)
plt.subplot(212)
plt.plot(l1,l3)
'''
#remove above 2 lines and run this if output obtained
plt.subplot(221)
plt.plot(l1,l3)
plt.subplot(222)
plt.plot(l1,l3)
'''
plt.savefig('plot1.png')