import numpy as np
import timeit

l1 = list(range(10000))
print(timeit.timeit("[i ** 2 for i in l1]", setup = 'from __main__ import l1', number = 100))

l2 = np.arange(10000)
print(timeit.timeit("[i ** 2 for i in l2]", setup = "from __main__ import l2", number = 100))

print(timeit.timeit("l2 ** 2", setup = "from __main__ import l2", number = 100))

print(type(l1))
print(type(l2))
#print(l1 ** 2)
print(l2 ** 2)