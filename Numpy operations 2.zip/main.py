import numpy as np

'''Array multiplication'''
a = np.arange(2*3).reshape(2,3)
b = np.eye(3,2)

print("A:{}\n".format(a))
print("B:{}\n".format(b))

c = a.dot(b)

print("C:{}\n".format(c))
del a,b,c

''' Test broadcasting and understand its power'''
#Addition of matching dimensions
print("Array addition without broadcasting:\n")
a = np.tile(np.random.rand(5),(5,1))
print("Array A: {}\n".format(a))

b = np.tile(np.random.rand(5),(5,1))
print("Array B: {}\n".format(b))

c = a + b
print("Array C: {}\n".format(c))

del a,b,c

print("Array addition with broadcasting:\n")
a = np.random.rand(5)
print("Array A: {}\n".format(a))

b = np.random.rand(5)
b = b[:,np.newaxis]
print("Array B: {}\n".format(b))

c = a + b
print("Array C: {}\n".format(c))

del a,b,c

#Ravelling of array
a = np.random.randn(3,3)
print("Array A:{}\n".format(a))
print("Flattened: {}\n".format(a.ravel(),axis = 0))