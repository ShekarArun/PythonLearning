'''
Program to check numpy array operations
'''
import numpy as np

'''l1 = list(range(10))

a = np.array(l1)
b = np.ones(10) * 3
print(a*b)

#print(np.log(0))
'''

#Array broadcasting testing
#First, normal addition with matching dimensions
a = np.tile(np.arange(0,40,10),(3,1))
a = a.T
print("A: {}".format(a))
b = np.tile(np.array([0,1,2]),(4,1))
print("B: {}".format(b))
c = a + b
print("C: {}".format(c))