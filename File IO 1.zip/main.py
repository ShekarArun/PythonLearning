import os

os.chdir("new1")
print(os.getcwd())

try:
  #Create a file and write data into it
  f = open("file1.txt",'w')
  f.write("Hey there!\nI've written into this file now haha\nJust testing out writing of multiple lines\n")
  print(f.tell())
finally:
  f.close()

try:
  f = open("file1.txt",'a')
  #print(f.read()) Error because not currently in read mode
  print(f.tell())
  f.write("This is an additional line in the file\n")
  print(f.tell())
finally:
  f.close()

try:
  f = open("file1.txt",'r')
  print(f.read())
finally:
  f.close()

try:
  f = open("file1.txt",'w')
  print(f.tell())
  #print(f.read())
  print(f.tell())
finally:
  f.close()

try:
  f = open("file1.txt",'r')
  print(f.read())
finally:
  f.close()